const defaultText = "Hover over a contestant below to view their target and round score.";

function upDate(previewPic) {
  console.log("Hovering over: ", previewPic.alt);

  const imageDiv = document.getElementById('image');
  const quote = previewPic.getAttribute('data-quote');
  const targetId = previewPic.getAttribute('data-target');
  const targetName = previewPic.getAttribute('data-target-name');
  const scoreVal = previewPic.getAttribute('data-score');
  const scoreText = previewPic.getAttribute('data-score-text');

  imageDiv.style.backgroundImage = `url('${previewPic.src}')`;
  imageDiv.innerHTML = `${quote} <br><span style="font-size:0.85rem; color:#ffd700;">[Target Aimed At: ${targetName}]</span>`;

  document.getElementById('score-fill').style.width = scoreVal + "%";
  document.getElementById('score-num').textContent = scoreVal + "%";
  document.getElementById('score-label').textContent = scoreText;

  const roundToggle = document.getElementById('round-toggle');
  if (previewPic.id === 'char-till') {
    roundToggle.style.display = "flex";
  } else {
    roundToggle.style.display = "none";
  }

  if (targetId) {
    const targetElement = document.getElementById(targetId);
    if (targetElement) {
      targetElement.classList.add('target-active');
    }
  }
}

function unDo() {
  const imageDiv = document.getElementById('image');

  imageDiv.style.backgroundImage = "url('')";
  imageDiv.innerHTML = defaultText;

  document.getElementById('score-fill').style.width = "0%";
  document.getElementById('score-num').textContent = "0%";
  document.getElementById('score-label').textContent = "Performance Power Meter";
  document.getElementById('round-toggle').style.display = "none";

  const allPreviews = document.querySelectorAll('.preview');
  allPreviews.forEach(img => img.classList.remove('target-active'));
}

function setTillRound(roundNumber) {
  const tillImg = document.getElementById('char-till');
  if (roundNumber === 6) {
    tillImg.setAttribute('data-score', '89');
    tillImg.setAttribute('data-score-text', 'Round 6 Victory: 89 pts (vs. Ivan: 70)');
    tillImg.setAttribute('data-target', 'char-ivan');
    tillImg.setAttribute('data-target-name', 'Ivan');
  } else if (roundNumber === 7) {
    tillImg.setAttribute('data-score', '47.2');
    tillImg.setAttribute('data-score-text', 'Round 7 Final: 47.2% (vs. Luka: 52.8%)');
    tillImg.setAttribute('data-target', 'char-luka');
    tillImg.setAttribute('data-target-name', 'Luka');
  }
  upDate(tillImg);
}

document.addEventListener("DOMContentLoaded", () => {
  const previews = document.querySelectorAll(".preview");
  previews.forEach((pic) => {
    pic.addEventListener("focus", () => upDate(pic));
    pic.addEventListener("blur", unDo);
  });
});

// Interactive Input Query
function checkFavorite(name) {
  const responseElement = document.getElementById('vote-response');
  const cleanName = name.trim().toLowerCase();

  if (cleanName === "") {
    responseElement.textContent = "Hover over a character to inspect relationships.";
    return;
  }

  const responses = {
    "mizi": "Mizi selected. Aimed at Sua (Round 1).",
    "sua": "Sua selected. Aimed at Mizi (Round 1).",
    "till": "Till selected. Multi-round vocalist (Round 6 vs. Ivan / Round 7 vs. Luka).",
    "ivan": "Ivan selected. Aimed at Till (Round 6).",
    "luka": "Luka selected. Aimed at Hyuna (Round 7 Champion).",
    "hyuna": "Hyuna selected. Aimed at Luka (Rebel Disruption)."
  };

  responseElement.textContent = responses[cleanName] || `Vocalist "${name}" logged in terminal.`;
}