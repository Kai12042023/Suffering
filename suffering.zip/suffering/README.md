# Suffering

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/Kai12042023/pen/01a106ad-c237-70fd-ae1a-6c749f313cc5](https://codepen.io/editor/Kai12042023/pen/01a106ad-c237-70fd-ae1a-6c749f313cc5).

